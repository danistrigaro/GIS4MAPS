# org.apache.cordova.battery-status

Plugin documentation: [doc/index.md](doc/index.md)
